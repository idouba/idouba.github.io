import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/* 
 * @(#)NATCluster.java	 2012-5-2
 *
 * YUANWANG HIGHLY CONFIDENTIAL INFORMATION: 
 * THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF YUANWANG 
 * INCORPORATED AND MAY BE PROTECTED BY ONE OR MORE PATENTS. USE, DISCLOSURE, OR 
 * REPRODUCTION OF ANY PORTION OF THIS SOFTWARE IS PROHIBITED WITHOUT THE PRIOR 
 * EXPRESS WRITTEN PERMISSION OF YUANWANG INCORPORATED. 
 * Copyright 2009 YUANWANG Incorporated. All rights reserved as an unpublished 
 * work. 
 * 
 */

/*
 Modification Log:
 -----------------------------------------------------------------------------------
 Version   format         By                Notes
 ----   ----------   ----------------	-------------------------------------------
 V1.0   2011/12/12     The developer       Create

 -----------------------------------------------------------------------------------

 */

/**

 $format$
 $Author$
 $Rev$
 */

/**
 * @author Administrator
 *
 */
public class NATCluster 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
//		traverse(loadExamplse());
//		normalize(Calendar.getInstance().getTime());
		
		try {
			System.out.println(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:04")));
			System.out.println(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27  5:04")));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Start cluster");
		
		Clusters clusterRe= cluster(loadExamplse());
		
		int i = 1;
		for(Cluster c: clusterRe.getElements())
		{
			System.out.println(i + " "  + c);
			i++;
		}

	}
	
	
	public static Date normalize(Date input)
	{
		System.out.println(Point.DATEFORMAT.format(input));
		try {
			System.out.println(Point.DATEFORMAT.parse(Point.DATEFORMAT.format(input)));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Calendar c = Calendar.getInstance();
		c.setTime(input);
//		c.set(Calendar.YEAR, -1);
//		c.set(Calendar.MONTH, 0);
//		c.set(Calendar.DATE, 0);
		
//        c.getTime().
		
		System.out.println(Point.INPUT_DATEFORMAT.format(c.getTime()));
		
		
		
		
		return input;
	}
	
	
	public static long getNormalizedTime(Date input)
	{
		Calendar c = Calendar.getInstance();
		c.setTime(input);
		
		return (c.get(Calendar.HOUR_OF_DAY)*60 + c.get(Calendar.MINUTE))*60 ; 
	}
	
	public static List<Point> loadExamplse()
	{
		
		
		List<Point> samples = new ArrayList<Point>();
		
		
		try {
			
//			Date firstSample = Point.DATEFORMAT.parse("2012-4-27 15:04");
			
			
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:04")),	15186	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:04")),	16913	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:09")),	20542	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:14")),	23589	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:14")),	24677	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:19")),	24855	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:19")),	25499	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:19")),	26052	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:24")),	27305	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:29")),	27357	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:29")),	27999	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:29")),	28616	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:34")),	29247	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:34")),	29841	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:39")),	31637	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:44")),	109	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:44")),	32318	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:49")),	180	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:49")),	1349	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:54")),	2668	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:59")),	2691	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 15:59")),	3925	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:04")),	5154	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:09")),	5767	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:09")),	6928	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:14")),	8197	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:19")),	9431	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:19")),	8238	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:19")),	8842	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:24")),	10723	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:29")),	11326	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:29")),	12534	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:34")),	12667	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:34")),	13612	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:39")),	14792	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:39")),	15345	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:44")),	15392	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:44")),	16626	));
			
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:49")),	17275	));
			samples.add(new Point(getNormalizedTime(Point.INPUT_DATEFORMAT.parse("2012-4-27 16:49")),	17923	));
				
				

			
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		Collections.sort(samples);
		Collections.sort(samples,
		new Comparator<Point>()
		{
			public int compare(Point o1, Point o2)
			{
				int timeDiff = Long.valueOf(o1.getTime()).compareTo(Long.valueOf(o2.getTime()));
				if( timeDiff == 0)
				{
					return Long.valueOf(o1.getSeqNum()).compareTo(Long.valueOf(o2.getSeqNum()));
				}
				else
				{
					return timeDiff;
				}
			}
			
		}
		);
		
		
		
		return samples;		
	}
	
	
	
	public static Clusters  cluster(List<Point> samples)
	{
		Clusters clusters = new Clusters();
		
		boolean cluserted = false;
		
		for(Point sample: samples)
		{
			{
				for(Cluster c: clusters.getElements())
				// close to the cluster
				if(!c.isDistanceDeviat(sample,clusters))
				{
					c.addElemment(sample);
					
					cluserted = true;
					break;
				}
			}
			
			//if not clustered to the previous collection, create a new cluster
			if(!cluserted)
			{
				Cluster c = new Cluster(sample);
				clusters.addCluster(c);
			}
			
			cluserted = false;
		}
		
		
		return clusters;
		
	}
	

	
	public static void traverse(List<Point> samples)
	{
		for(Point sample: samples)
		{
			System.out.println(sample);
		}
		
	}
	
	
	

}
