import java.util.ArrayList;
import java.util.List;

/* 
 * @(#)Clusters.java	 2012-5-3
 *
 * YUANWANG HIGHLY CONFIDENTIAL INFORMATION: 
 * THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF YUANWANG 
 * INCORPORATED AND MAY BE PROTECTED BY ONE OR MORE PATENTS. USE, DISCLOSURE, OR 
 * REPRODUCTION OF ANY PORTION OF THIS SOFTWARE IS PROHIBITED WITHOUT THE PRIOR 
 * EXPRESS WRITTEN PERMISSION OF YUANWANG INCORPORATED. 
 * Copyright 2009 YUANWANG Incorporated. All rights reserved as an unpublished 
 * work. 
 * 
 */

/*
 Modification Log:
 -----------------------------------------------------------------------------------
 Version   Date         By                Notes
 ----   ----------   ----------------	-------------------------------------------
 V1.0   2011/12/12     The developer       Create

 -----------------------------------------------------------------------------------

 */

/**

 $Date$
 $Author$
 $Rev$
 */

/**
 * @author Administrator
 *
 */
public class Clusters {

	private List<Cluster> elements;
	
	
	
	/**
	 * 
	 */
	public Clusters() 
	{
		elements = new ArrayList<Cluster>();
	}
	

	
	public List<Cluster> getElements()
	{
		return elements;
	}
	
	public int getClusterSize()
	{
		return elements.size();
	}
	
	public void addCluster(Cluster c)
	{
//		pointsSize = pointsSize +  c.size();
//		sumVerticalDistance =sumVerticalDistance + c.getSumVerticalDistance();888654
//		sumDistance = sumDistance + c.getSumDistance();
		
		
		elements.add(c);
	}
	
	public long getAverageVerticalDistance()
	{
		long sumVerticalDistance = 0;
		int pointSize = 0;
		for(Cluster c: this.elements)
		{
			sumVerticalDistance = sumVerticalDistance + c.getAverageVerticalDistance()*c.size() ;
			pointSize = pointSize + c.size();
		}
		
		System.out.println("sumVerticalDistance = " + sumVerticalDistance);
		System.out.println("pointSize = " + pointSize);
		System.out.println("getAverageVerticalDistance = " + sumVerticalDistance/pointSize);
		
		
		return sumVerticalDistance/pointSize;
	}
	
	public double getAverageDistance()
	{
		double sumDistance = 0;
		int pointSize = 0;
		for(Cluster c: this.elements)
		{
			sumDistance =sumDistance + c.getAverageDistance()*c.size() ;
			pointSize =pointSize + c.size();
		}
		
		System.out.println("sumDistance = " + sumDistance);
		System.out.println("pointSize = " + pointSize);
		System.out.println("getAverageDistance = " + sumDistance/pointSize);
		
		return sumDistance/pointSize;
	}
	
	
	
	
	

}
