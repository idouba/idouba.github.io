import java.util.ArrayList;
import java.util.List;

/* 
 * @(#)Cluster.java	 2012-5-3
 *
 * YUANWANG HIGHLY CONFIDENTIAL INFORMATION: 
 * THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF YUANWANG 
 * INCORPORATED AND MAY BE PROTECTED BY ONE OR MORE PATENTS. USE, DISCLOSURE, OR 
 * REPRODUCTION OF ANY PORTION OF THIS SOFTWARE IS PROHIBITED WITHOUT THE PRIOR 
 * EXPRESS WRITTEN PERMISSION OF YUANWANG INCORPORATED. 
 * Copyright 2009 YUANWANG Incorporated. All rights reserved as an unpublished 
 * work. 
 * 
 */

/*
 Modification Log:
 -----------------------------------------------------------------------------------
 Version   Date         By                Notes
 ----   ----------   ----------------	-------------------------------------------
 V1.0   2011/12/12     The developer       Create

 -----------------------------------------------------------------------------------

 */



/**
 * @author Administrator
 *
 */
public class Cluster 
{
	
	public static double DISTANCE_DEVIATION_INDEX = 29;
	public static long DISTANCE_VERTICAL_DEVIATION_INDEX = 30;

	/**
	 * 
	 */
	public Cluster() {
		this.elements = new ArrayList<Point>();
		this.maxDistance = -1;
		this.maxVerticalDistance = -1;
	}
	
	/**
	 * @param mean
	 */
	public Cluster(Point mean) {
		super();
		this.maxDistance = -1;
		this.maxVerticalDistance = -1;
		this.elements = new ArrayList<Point>();
		elements.add(mean);
	}
	
	/**
	 * @param mean
	 * @param elements
	 */
	public Cluster(Point mean, List<Point> elements) {
		super();
		this.maxDistance = -1;
		this.maxVerticalDistance = -1;
		elements.add(mean);
		this.elements = elements;
	}
	
	
	public void addElemment(Point p)
	{		
		if(!isEmpty())
		{
			
		Point lastElement = elements.get(elements.size()-1);
		
		if(lastElement != null)
		{
		
		long verticalDistance = p.getVerticalDistance(lastElement);
		double distance = p.getDistance(lastElement);
		maxVerticalDistance = Math.max(maxVerticalDistance,verticalDistance );
		maxDistance = Math.max(maxDistance, distance);
		
		this.sumVertaicalDistance = sumVertaicalDistance + verticalDistance;
		this.sumDistance = sumDistance + distance;		
		
		}
		}
		
		elements.add(p);
		
	}
	
	
	
	public long getVerticalDistance(Point p)
	{
		if(isEmpty())
		{
			return -1;
		}
		Point lastElement = elements.get(elements.size()-1);
//		System.out.println("lastElement = " +lastElement);
//		System.out.println("tryElement = " +p);
		
		return  p.getVerticalDistance(lastElement);
	}
	
	public double getDistance(Point p)
	{		
		if(isEmpty())
		{
			return -1;
		}
		
		Point lastElement = elements.get(elements.size()-1);		
		return  p.getDistance(lastElement);
	}
	
	
	public boolean isDistanceDeviat(Point p, Clusters cs)
	{
		double distance = getDistance(p);
		double globalDistance = cs.getAverageVerticalDistance();
		
		System.out.println("globalDistance = " + globalDistance);
		
		if(distance != -1 && maxDistance != -1 
				&& distance > DISTANCE_DEVIATION_INDEX * (this.maxDistance + globalDistance) /2)
		{
			return true;
		}
		
		else
		{
			return false;
		}
	}
	
	
	public boolean isVerticalDistanceDeviat(Point p, Clusters cs)
	{
		long verticalDistance = getVerticalDistance(p);
		long globalVerticalDistance = cs.getAverageVerticalDistance();
		
		
		
//		System.out.println("maxVerticalDistance = " + maxVerticalDistance);
//		System.out.println("verticalDistance = " + verticalDistance);
		
		if(verticalDistance != -1 && maxVerticalDistance != -1 
				&& verticalDistance > DISTANCE_VERTICAL_DEVIATION_INDEX * (this.maxVerticalDistance + globalVerticalDistance)/2)
		{
			return true;
		}
		
		else
		{
			return false;
		}
	}



	
	public boolean isEmpty()
	{
		return this.elements.isEmpty();
	}
	
	
	public int size()
	{
		return elements.size();
	}
	
	/**
	 * sum of vertical distance, sequencely one by one, not one to every other one.
	 * @return
	 */
	public long getSumVerticalDistance()
	{
		return sumVertaicalDistance;
	}
	
	public double getSumDistance()
	{
		return sumDistance;
	}
	
	public long getAverageVerticalDistance()
	{
		return sumVertaicalDistance/size();
	}
	
	public double getAverageDistance()
	{
		return sumDistance/size();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer sb =  new StringBuffer("Cluster:" + ", maxVerticalDistance=" + maxVerticalDistance
				+ ", maxDistance=" + maxDistance + "\r\n");
		
		for(Point p: this.elements)
		{
			sb.append(p);
			sb.append("\r\n");
		}
		
		return new String(sb);
	}
	
	



   

	private List<Point> elements;
	private long maxVerticalDistance; 
	private double maxDistance;
	
	private long sumVertaicalDistance;
	private double sumDistance;
	
	
	

}
