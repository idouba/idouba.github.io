import java.util.Comparator;

/* 
 * @(#)PointComparator.java	 2012-5-2
 *
 * YUANWANG HIGHLY CONFIDENTIAL INFORMATION: 
 * THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF YUANWANG 
 * INCORPORATED AND MAY BE PROTECTED BY ONE OR MORE PATENTS. USE, DISCLOSURE, OR 
 * REPRODUCTION OF ANY PORTION OF THIS SOFTWARE IS PROHIBITED WITHOUT THE PRIOR 
 * EXPRESS WRITTEN PERMISSION OF YUANWANG INCORPORATED. 
 * Copyright 2009 YUANWANG Incorporated. All rights reserved as an unpublished 
 * work. 
 * 
 */

/*
 Modification Log:
 -----------------------------------------------------------------------------------
 Version   Date         By                Notes
 ----   ----------   ----------------	-------------------------------------------
 V1.0   2011/12/12     The developer       Create

 -----------------------------------------------------------------------------------

 */

/**

 $Date$
 $Author$
 $Rev$
 */

/**
 * @author Administrator
 *
 */
public class DistanceVerticalComparator implements Comparator<Distance> 
{

	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int compare(Distance o1, Distance o2)
	{
		// TODO Auto-generated method stub
		return o1.getVerticalDistance() < o2.getVerticalDistance() ? -1:( o1.getVerticalDistance() == o2.getVerticalDistance() ? 0:1);
	}

}
