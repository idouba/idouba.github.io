import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/* 
 * @(#)Point.java	 2012-5-2
 *
 * YUANWANG HIGHLY CONFIDENTIAL INFORMATION: 
 * THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF YUANWANG 
 * INCORPORATED AND MAY BE PROTECTED BY ONE OR MORE PATENTS. USE, DISCLOSURE, OR 
 * REPRODUCTION OF ANY PORTION OF THIS SOFTWARE IS PROHIBITED WITHOUT THE PRIOR 
 * EXPRESS WRITTEN PERMISSION OF YUANWANG INCORPORATED. 
 * Copyright 2009 YUANWANG Incorporated. All rights reserved as an unpublished 
 * work. 
 * 
 */

/*
 Modification Log:
 -----------------------------------------------------------------------------------
 Version   Date         By                Notes
 ----   ----------   ----------------	-------------------------------------------
 V1.0   2011/12/12     The developer       Create

 -----------------------------------------------------------------------------------

 */


public class Point implements Comparable<Point>
{
	
	public static final SimpleDateFormat INPUT_DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	public static final SimpleDateFormat DAY_DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd");
	public static final SimpleDateFormat DATEFORMAT = new SimpleDateFormat("HH:mm");
	
	/**
	 * @param time
	 * @param seqNum
	 */
	public Point(long time, long seqNum) {
		super();
		this.time = time;
		this.seqNum = seqNum;
	}
	
	private long time;
	private long seqNum;
	/**
	 * @return the time
	 */
	public long getTime() 
	{
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(long time) 
	{
		this.time = time;
	}
	/**
	 * @return the seqNum
	 */
	public long getSeqNum() 
	{
		return seqNum;
	}
	/**
	 * @param seqNum the seqNum to set
	 */
	public void setSeqNum(long seqNum) 
	{
		this.seqNum = seqNum;
	}
	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Point o) {
		
		int timeDiff = Long.valueOf(this.getTime()).compareTo(Long.valueOf(o.getTime()));
		if( timeDiff == 0)
		{
			return Long.valueOf(this.getSeqNum()).compareTo(Long.valueOf(o.getSeqNum()));
		}
		else
		{
			return timeDiff;
		}
		
	}
	
	
	public double getDistance(Point neighbor)
	{
		if(neighbor == null)
		{
			return -1;
		}
		else
		{
		return Math.pow((time - neighbor.getTime()), 2) + Math.pow((this.seqNum - neighbor.getSeqNum()), 2);
		}
		
	}
	
	public long getVerticalDistance(Point neighbor)
	{
		if(neighbor == null)
		{
			return -1;
		}
		else
		{
		return Math.abs(this.seqNum - neighbor.getSeqNum());
		}
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		
		return compareTo((Point)obj) ==0;
	}
	
	
	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
//		return "Point timestr=" + Point.DATEFORMAT.format(new Date(time*1000*60)) + ", seqNum=" + seqNum + ", time=" + time;
		Calendar c = Calendar.getInstance();
		long baseTime = 0;
		
		try {
			baseTime = DAY_DATEFORMAT.parse(DAY_DATEFORMAT.format(c.getTime())).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return  Point.INPUT_DATEFORMAT.format(new Date(baseTime + time*1000)) + "  " + seqNum + " " + time;
	}
	
	

}
