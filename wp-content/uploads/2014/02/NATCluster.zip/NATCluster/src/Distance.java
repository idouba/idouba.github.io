/* 
 * @(#)Distance.java	 2012-5-3
 *
 * YUANWANG HIGHLY CONFIDENTIAL INFORMATION: 
 * THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF YUANWANG 
 * INCORPORATED AND MAY BE PROTECTED BY ONE OR MORE PATENTS. USE, DISCLOSURE, OR 
 * REPRODUCTION OF ANY PORTION OF THIS SOFTWARE IS PROHIBITED WITHOUT THE PRIOR 
 * EXPRESS WRITTEN PERMISSION OF YUANWANG INCORPORATED. 
 * Copyright 2009 YUANWANG Incorporated. All rights reserved as an unpublished 
 * work. 
 * 
 */

/*
 Modification Log:
 -----------------------------------------------------------------------------------
 Version   Date         By                Notes
 ----   ----------   ----------------	-------------------------------------------
 V1.0   2011/12/12     The developer       Create

 -----------------------------------------------------------------------------------

 */

/**

 $Date$
 $Author$
 $Rev$
 */

/**
 * @author Administrator
 *
 */
public class Distance implements Comparable<Distance> 
{
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Distance [start=" + start + ", end=" + end + ", distance="
				+ distance;
	}

	private Point start;
	private Point end;
	
	private double distance;
	private long verticalDistance;

	/**
	 * @param start
	 * @param end
	 */
	public Distance(Point start, Point end) {
		super();
		this.start = start;
		this.end = end;
		this.distance = start.getDistance(end);
		this.verticalDistance = start.getVerticalDistance(end);
	}

	/**
	 * @return the start
	 */
	public Point getStart() {
		return start;
	}

	/**
	 * @return the verticalDistance
	 */
	public long getVerticalDistance() {
		return verticalDistance;
	}

	/**
	 * @param verticalDistance the verticalDistance to set
	 */
	public void setVerticalDistance(long verticalDistance) {
		this.verticalDistance = verticalDistance;
	}

	/**
	 * @param start the start to set
	 */
	public void setStart(Point start) {
		this.start = start;
	}

	/**
	 * @return the end
	 */
	public Point getEnd() {
		return end;
	}

	/**
	 * @param end the end to set
	 */
	public void setEnd(Point end) {
		this.end = end;
	}

	/**
	 * @return the distance
	 */
	public double getDistance() {
		return distance;
	}

	/**
	 * @param distance the distance to set
	 */
	public void setDistance(double distance) {
		this.distance = distance;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Distance o) {
		// TODO Auto-generated method stub
		return this.getDistance() < o.getDistance() ? -1:( this.getDistance() == o.getDistance() ? 0:1);
	}


	
	

}
