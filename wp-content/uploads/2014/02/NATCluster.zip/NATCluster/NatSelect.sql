SELECT [Id]
      ,[UniqueId]
      ,[PolicyId]
      ,[SourceIP]
      ,[SourceMac]
      ,[Port]
      ,[TTL]
      ,[SeqNum]
      ,[IP]
      ,[DiscoveryTime]
      ,[UpdateTime]
  FROM [yuanwangSMP_GA].[dbo].[Log_NAT] where updateTime>'2012-09-02' and updateTime<'2012-09-03'
        and
        sourceIp = '192.168.1.201'

SELECT [Id]
      ,[UniqueId]
      ,[PolicyId]
      ,[SourceIP]
      ,[SourceMac]
      ,[Port]
      ,[TTL]
      ,[SeqNum]
      ,[IP]
      ,[DiscoveryTime]
      ,[UpdateTime]
  FROM [yuanwangSMP_GA].[dbo].[Log_NAT] where updateTime>'2012-08-02' and updateTime<'2012-08-03'
        and
        sourceIp = '192.168.1.185'

SELECT [Id]
      ,[UniqueId]
      ,[PolicyId]
      ,[SourceIP]
      ,[SourceMac]
      ,[Port]
      ,[TTL]
      ,[SeqNum]
      ,[IP]
      ,[DiscoveryTime]
      ,[UpdateTime]
  FROM [yuanwangSMP_GA].[dbo].[Log_NAT] where updateTime>'2012-09-02' and updateTime<'2012-09-03'
        and
        sourceIp = '192.168.1.185'


SELECT [Id]
      ,[UniqueId]
      ,[PolicyId]
      ,[SourceIP]
      ,[SourceMac]
      ,[Port]
      ,[TTL]
      ,[SeqNum]
      ,[IP]
      ,[DiscoveryTime]
      ,[UpdateTime]
  FROM [yuanwangSMP_GA].[dbo].[Log_NAT] where updateTime>'2012-08-02' and updateTime<'2012-08-03'
        and
        IP = '192.168.2.192'



