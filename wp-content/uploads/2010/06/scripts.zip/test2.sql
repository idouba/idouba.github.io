alter procedure test2
as
begin
begin tran

update T set cname = 'test1' where age = 11

waitfor delay '00:00:020:00'

select * from dbo.T where age = 12

rollback 

end