alter procedure test1
as
begin

begin tran

update T set cname = 'test1' where age = 12

waitfor delay '00:00:020:00'

select * from dbo.T where age = 11


rollback 

end